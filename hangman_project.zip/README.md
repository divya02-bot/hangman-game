# Hangman Game (Python)

A complete beginner-friendly, text-based Hangman game. It uses five built-in words, chooses one at random, accepts one-letter guesses, and allows up to six incorrect guesses. It needs no extra Python packages.

## What tools to use

- **Python 3** runs the program.
- **Visual Studio Code** (recommended) is where you can view or edit `hangman.py`. Notepad can also edit it.
- **PowerShell / Terminal** runs the game. You do not need GitHub to run it locally.

## Setup and run on Windows

1. Install Python 3 from [python.org](https://www.python.org/downloads/) if it is not already installed. During setup, enable **Add Python to PATH**.
2. Download or copy the `hangman_project` folder to a location you can find, such as **Documents**.
3. Open that folder in Visual Studio Code: **File → Open Folder** → select `hangman_project`.
4. Open `hangman.py` to inspect or edit the code.
5. In VS Code, choose **Terminal → New Terminal**. The terminal should be in the project folder. If it is not, use `cd` to move into the folder. For example:

   ```powershell
   cd "$HOME\Documents\hangman_project"
   ```

6. Start the game by entering:

   ```powershell
   python hangman.py
   ```

   If `python` is not recognized, try `py hangman.py`. If neither works, install Python and make sure it was added to PATH.

7. Type one letter and press **Enter** each turn. Correct guesses reveal letters; six incorrect guesses end the game. Run the command again to play another round.

## Project files

- `hangman.py` — the complete game source code.
- `README.md` — these setup and run instructions.

## What the code demonstrates

- Lists and `random.choice` to select a secret word
- A `while` loop to continue the game
- `if` / `else` checks for guesses and win/loss conditions
- Strings, input validation, and a `set` to remember guessed letters
